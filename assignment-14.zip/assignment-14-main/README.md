# Ostad_assignment_M14

#live project Link 
https://ostad-assignment-m14.netlify.app/
the project not responsive for mobile and tablet viwe 

